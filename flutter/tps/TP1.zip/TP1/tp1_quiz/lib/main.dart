import 'package:flutter/material.dart';
import 'screens/quiz_page.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Quiz NBA',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: const QuizPage(title: 'Quiz NBA'),
    );
  }
}
