package com.example.tp1_quiz

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
